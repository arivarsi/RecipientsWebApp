{
    "theme_color": "#FF0000",
    "orientation": "any",
    "background_color": "#FFFFFF",
    "display": "standalone",
    "name": "RecipientsWebApp",
    "id": "RecipientsWebApp",
    "short_name": "RecipientsWebApp",
    "start_url": "/apps/RecipientsWebApp/",
    "icons": [{
        "sizes": "48x48",
        "type": "image/png",
        "src": "images/voltmx_48.png"
    }, {
        "sizes": "72x72",
        "type": "image/png",
        "src": "images/voltmx_48.png"
    }, {
        "sizes": "96x96",
        "type": "image/png",
        "src": "images/voltmx_88.png"
    }, {
        "sizes": "144x144",
        "type": "image/png",
        "src": "images/voltmx_150.png"
    }, {
        "sizes": "168x168",
        "type": "image/png",
        "src": "images/voltmx_150.png"
    }, {
        "type": "image/png",
        "sizes": "192x192",
        "src": "images/voltmx_300.png"
    }, {
        "type": "image/png",
        "sizes": "512x512",
        "src": "images/voltmx_300.png"
    }],
    "related_applications": [{
        "platform": "web",
        "url": "http://localhost:port/apps/RecipientsWebApp/"
    }]
}